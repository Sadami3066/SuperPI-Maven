package io.github.whywood.superpi.design

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun DdEmptyState(
    text: String,
    modifier: Modifier = Modifier,
) {
    Text(
        text = text,
        modifier = modifier.fillMaxWidth().padding(horizontal = DdSpacing.Lg),
        style = DdType.bodySmall,
        color = superPiColors().inkTertiary,
        textAlign = TextAlign.Center,
    )
}

@Composable
fun DdEmptyState(
    text: String,
    icon: DdIcon,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null,
) {
    val colors = superPiColors()
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = DdSpacing.Lg, vertical = DdSpacing.Xxl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DdSpacing.Md),
    ) {
        DdIcon(
            icon = icon,
            size = 24.dp,
            tint = colors.inkTertiary,
        )
        DdText(
            text = text,
            style = DdType.bodySmall,
            color = colors.inkTertiary,
            textAlign = TextAlign.Center,
        )
        if (action != null) {
            action()
        }
    }
}
