package io.github.whywood.superpi.sdk.ai.auth

import io.github.whywood.superpi.sdk.ai.platform.platformEnv
import kotlinx.serialization.Serializable

fun interface AuthContext {
    fun env(name: String): String?
}

object SystemAuthContext : AuthContext {
    override fun env(name: String): String? = platformEnv(name)?.takeIf { it.isNotBlank() }
}

object AuthEnvironment {
    var context: AuthContext = SystemAuthContext

    fun env(name: String): String? = context.env(name)?.takeIf { it.isNotBlank() }
}

data class AuthOverrides(
    val apiKey: String? = null,
    val env: Map<String, String>? = null,
)

data class ResolvedAuth(
    val apiKey: String?,
    val headers: Map<String, String> = emptyMap(),
    val source: String,
    val env: Map<String, String> = emptyMap(),
)

interface AuthResolver {
    suspend fun resolve(overrides: AuthOverrides? = null): ResolvedAuth?
}

enum class AuthType {
    ApiKey,
    OAuth,
}

@Serializable
data class ApiKeyCredential(
    val type: String = "api_key",
    val key: String? = null,
    val env: Map<String, String>? = null,
) : Credential

@Serializable
data class OAuthCredential(
    val type: String = "oauth",
    val refresh: String,
    val access: String,
    val expires: Long,
) : Credential

sealed interface Credential
